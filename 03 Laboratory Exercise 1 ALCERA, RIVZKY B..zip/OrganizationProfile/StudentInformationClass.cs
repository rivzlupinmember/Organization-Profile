﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrganizationProfile
{
    internal class StudentInformationClass
    {
        public static long SetStudentNo { get; set; } = 0;
        public static long SetContactNo { get; set; } = 0;
        public static string SetProgram { get; set; } = "";
        public static string SetGender { get; set; } = "";
        public static string SetBirthday { get; set; } = "";
        public static string SetFullName { get; set; } = "";
        public static int SetAge { get; set; } = 0;
    }
}